﻿/*
 * Designed By: Ammanuel Lakew
 * cio1fhogr5jqi@gmail.com
 * 206-278-2095
 */
using System;
using System.Collections;
using System.Net;


namespace Crawler_Code_Challenge
{
    class Program
    {
        static void Main()
        {

            //Browse the website and get all the words from the webpage
            var Client = new WebClient();
            SortedList Result = new SortedList();
            string Url = GetUrl();
            if (Url != null)
            {
                string WebPage = Client.DownloadString(Url);
                
                //Go through the webpage content and split or omit the non-words
                string[] Source = WebPage.Split(new char[] { ' ', ',', '.', ':', '\t','<','>','/',';','"','[',']','{','}', '=', '+','=','(',')','*','&','^','%','$','#','@','!','~','`','1','2','3','4','5','6','7','8','9','0'});
           
            //Count all the repeated words and store the result in Result Sorted list
            int Counter = 1;
            for (int Word = 0; Word < Source.Length; Word++)
            {
                Counter = 1;
                for (int Words = 0; Words < Source.Length; Words++)
                {
                    if (Source[Word].Trim().ToUpper() == Source[Words].Trim().ToUpper() && Word != Words)
                    {
                        Counter++;
                    }

                }

                if (Counter > 1 && !Result.Contains(Source[Word].Trim().ToUpper()))
                {

                    Result.Add(Source[Word].Trim().ToUpper(), Counter);

                }
            }
            }
        
            DisplayTheWords(Result);
        }

        public static string GetUrl()
        {

            //Get the Url
            string Url = "";
            Console.WriteLine("Enter the web address: ");
            return Url = Console.ReadLine();

        }
        public static void DisplayTheWords(SortedList Result)
        {
            //Display the words
            Console.WriteLine("     # of occurrences");
            foreach (DictionaryEntry Word in Result)
            {
                Console.WriteLine("| " + Word.Key + "   |  " + Word.Value + "  |");
            }
        }
    }


}


